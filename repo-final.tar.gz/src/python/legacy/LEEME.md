# Scripts heredados de la fase anterior

Estos cinco ficheros proceden de la primera fase del proyecto (el estudio de la
densidad topologica y el orden de fusion) y se conservan solo como registro.

Cuatro de ellos dependen de modulos auxiliares (`m.py`, `k3.py`) que ya no
forman parte del repositorio, de modo que **no se ejecutan tal cual**. El
contenido matematico que si sobrevivio esta reimplementado, de forma limpia y
autocontenida, en `lib.py`, `maxov.py` y `merge3.py` del directorio superior.
